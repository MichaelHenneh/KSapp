package kent.kentapp;

import org.junit.Test;

/**
 * Created by James on 30/03/2016.
 */
public class UnitTests {
    @Test
    public void test1() throws Exception {

    }

}